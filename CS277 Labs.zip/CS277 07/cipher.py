class Cipher:
    def __init__(self):
        self._alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'


    def encrypt_message(self, message):

        encryption_string = ''
        for i in message.upper():
            if i in self._alphabet:
                encryption_string += self._encrypt_letter(i)
            else:
                encryption_string += i

        return encryption_string




    def decrypt_message(self, message):

        decryption_string = ''
        for i in message.upper():
            if i in self._alphabet:
                decryption_string += self._decrypt_letter(i)
            else:
                decryption_string += i

        return decryption_string



    def _encrypt_letter(self, letter):

        location = self._alphabet.index(letter)
        encrpyt_ltr = 25 - location
        return self._alphabet[encrpyt_ltr]


    def _decrypt_letter(self, letter):

        location = self._alphabet.index(letter)
        encrpyt_ltr = 25 - location
        return self._alphabet[encrpyt_ltr]