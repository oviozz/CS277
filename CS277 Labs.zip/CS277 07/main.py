
import cipher
import CasesarCipher as casesar
import check_input


def main():

    if encrypt_type == 1:
        cip = cipher.Cipher()

        if selection == 1:
            file = open('message.txt', 'w+')
            input_string = input('Enter message: ')
            message = cip.encrypt_message(input_string)

            file.write(message)
            print('Encrypted message saved to “message.txt”.')

            file.close()

        else:
            file = open('message.txt', 'r')
            print('Reading encrypted message from “message.txt')
            message = cip.decrypt_message(file.read())
            print(f'Decrypted message: {message}')
            file.close()

    else:

        if selection == 1:
            input_string = input('Enter message: ')
            shift_value = int(input('Enter shift value: '))

            cae = casesar.CaesarChiper(shift_value)
            file = open('message.txt', 'w+')
            message = cae.encrypt_message(input_string)
            file.write(message)

            print('Encrypted message saved to “message.txt”.')
            file.close()

        else:
            shift_value = int(input('Enter shift value: '))
            file = open('message.txt', 'r')
            cae = casesar.CaesarChiper(shift_value)

            print('Reading encrypted message from “message.txt')
            message = cae.decrypt_message(file.read())
            print(f'Decrypted message: {message}')
            file.close()




if __name__ == "__main__":

    print('Secret Decorder Ring: ')
    selection = check_input.get_int_range('1. Encrypt\n2. Decrypt\n',1,2)

    print('Enter encryption type:')
    encrypt_type = check_input.get_int_range('1. Atbash\n2. Caesar\n',1,2)

    main()