import cipher


class CaesarChiper(cipher.Cipher):

    def __init__(self,shift : int):
        super().__init__()
        self.shift = shift


    def _encrypt_letter(self, letter):
        location = self._alphabet.index(letter)

        encrypt_ltr = location + self.shift

        length = len(self._alphabet)

        if encrypt_ltr > length - 1:
            return self._alphabet[(location + self.shift) - length]

        return self._alphabet[encrypt_ltr]


    def _decrypt_letter(self, letter):

        location = self._alphabet.index(letter)

        encrypt_ltr = location - self.shift

        return self._alphabet[encrypt_ltr]
