import rectangle
import check_input



def display_grid(grid):

    for rw in character_array:
        for cl in rw:
            print(cl, end='')
        print()


def reset_grid(grid):

    for row in range(len(grid)):
        grid[row] = ['. ' for i in grid[row]]

    return grid

def place_rect(grid, rect):


    width = rect[0]
    height = rect[1]

    for i in grid[obj.y:height]:
        for a in range(obj.y, height):
            for b in range(obj.x, width):
                character_array[a][b] = '* '


if __name__ == '__main__':

    character_array = []

    for row in range(20):
        character_array.append(['. ' for i in range(20)])

    rectangle_height = check_input.get_int_range('Enter rectangle height (1-5): ', 1, 5)
    rectangle_width = check_input.get_int_range('Enter rectangle width (1-5): ', 1, 5)

    obj = rectangle.Rectangle(rectangle_width,rectangle_height)

    display_grid(place_rect(character_array, [obj.get_width(),obj.get_height()]))


    direction_input = check_input.get_int_range('Enter Direction:\n1. Up\n2. Down\n3. Left\n4. Right\n5. Quit\n: ',1 ,5)

    while direction_input != 5:

        if direction_input == 1:
            if obj.y <= 0:
                print('-- Out of Bound -- ')
            else:
                obj.height += -1
                obj.y += -1

            reset_grid(character_array)
            display_grid(place_rect(character_array, [obj.get_width(), obj.get_height()]))

        if direction_input == 2:
            if obj.height >= 20:
                print('-- Out of Bound -- ')
            else:
                obj.height += 1
                obj.y += 1

            reset_grid(character_array)
            display_grid(place_rect(character_array, [obj.get_width(), obj.get_height()]))



        if direction_input == 3:
            if obj.x <= 0:
                print('-- Out of Bound -- ')
            else:
                obj.width -= 1
                obj.x -= 1

            reset_grid(character_array)
            display_grid(place_rect(character_array, [obj.get_width(),obj.get_height()]))


        if direction_input == 4:
            if obj.width >= 20:
                print('-- Out of Bound --')
            else:
                obj.width += 1
                obj.x += 1

            reset_grid(character_array)
            display_grid(place_rect(character_array, [obj.get_width(),obj.get_height()]))


        direction_input = check_input.get_int_range('Enter Direction:\n1. Up\n2. Down\n3. Left\n4. Right\n5. Quit\n: ', 1, 5)

