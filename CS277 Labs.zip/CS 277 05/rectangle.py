class Rectangle:
    def __init__(self, width, height):
        self.x = 0
        self.y = 0
        self.width = width
        self.height = height

    def get_coords(self):
        return [self.x,self.y]

    def get_width(self):
        return self.width

    def get_height(self):
        return self.height

    def move_up(self):
            self.y -= 1

    def move_down(self):
            self.y += 1


    def move_left(self):
            self.x -= 1

    def move_right(self):
            self.x += 1

