
import player
import tiger
import ocelot
import tabby
import check_input


def main():
    cat_select = check_input.get_int_range('Cat Selection:\n1. Tabby Cat\n2. Ocelot\n3. Tiger\nEnter choice: ', 1, 3)

    kitty_name = input('Name your kitty: ')

    cats = [tabby.Tabby(kitty_name),
            ocelot.Ocelot(kitty_name),
            tiger.Tiger(kitty_name)]

    user = player.Player()

    while user.hp > 0:
        print(f'\n{user}')

        chosen_cat = cats[cat_select - 1]
        print(chosen_cat)

        cat_menu = check_input.get_int_range(
            'Cat Menu:\n1. Feed your cat\n2. Play with your cat\n3. Pet your cat\nEnter your choice: ', 1, 3)

        if cat_menu == 1:
            print(chosen_cat.feed(user))

        elif cat_menu == 2:
            print(chosen_cat.play(user))

        elif cat_menu == 3:
            print(chosen_cat.pet(user))

    print('\nYour cat killed you...')






if __name__ == '__main__':
    main()