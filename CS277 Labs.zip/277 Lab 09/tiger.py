
import cat
import random

class Tiger(cat.Cat):

    def feed(self, player):
        if self.hunger < 10:
            self.update_hunger(5)
            player.take_damage(random.randint(3,10))
            return (f'{self._name} is pretty hungry and accidentally bites you when it takes the steak from your hand')

    def play(self, player):
        if self.hunger >= 9:
            self.update_hunger(-4)
            return (f'{self._name} is so full, when your throw the ball, it lays there sleepily in the sun.')


        elif self.hunger >= 7:
            player.take_damage(random.randint(1,8))
            self.update_hunger(-4)
            return (f'{self._name} jumps and plays with the soccer ball you threw, then accidentally tackles you when it comes running back.')


        elif self.hunger >= 4 and self.hunger <= 6:
            self.update_hunger(-2)
            return (f'{self._name} sniffs the basketball you have and then decides that you might be delicious. Fang bites you for {player.take_damage(random.randint(1,8))} damage.')


        elif self.hunger <= 3:
            self.update_hunger(-1)
            return (f"{self._name} is starving, they don't want to play right now. Fang stalks you, chases you down, tackles you, and takes a large chunk out of your arm for {player.take_damage(random.randint(1,10))} damage.")


    def pet(self, player):
        if self.hunger > 8:
            return (f'{self._name} is incredibly full and purrs happily as they drift off to sleep.')
        elif self.hunger > 6:
            return (f'{self._name} happily allows you to pet them.')


