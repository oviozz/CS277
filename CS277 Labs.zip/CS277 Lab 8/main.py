import check_input
import entity
import hero
import dragon
import fire_dragon
import flying_dragon
import random


def main():
    main_hero = hero.Hero(input('What is your name, challenger?\n').capitalize(),50)
    print(f'Welcome to dragon training, {main_hero.name}')
    print('You must defeat 3 dragons.\n')

    game_finished = 3

    list_dragon = [dragon.Dragon("Deadly Nadder", 10),
                   fire_dragon.FireDragon("Gronckle", 15, 3),
                   flying_dragon.FlyingDragon("Timberjack", 20, 5)]

    while game_finished != 0:

        if main_hero.hp <= 0:
            print('YOU DIED!')
            exit()

        print(main_hero)

        for i in range(0, len(list_dragon)):
            print(f'{i+1}. Attack {list_dragon[i]}')

        choose_dragon = check_input.get_int_range('Choose a dragon to attack: ', 1, len(list_dragon))

        weapon_choose = check_input.get_int_range('\nAttack with:\n1. Arrow (1 D12)\n2. Sword (2 D6)\nEnter weapon: ',
                                                  1, 2)

        cur_dragon_name = list_dragon[choose_dragon - 1]

        dragon_attack = random.randint(1,2)


        if weapon_choose == 1:
            print(f"\n{main_hero.arrow_attack(cur_dragon_name)}")
            if dragon_attack == 1:
                print(f"{cur_dragon_name.name} {cur_dragon_name.basic_attack(main_hero)}\n")
            else:
                print(f"{cur_dragon_name.name} {cur_dragon_name.special_attack(main_hero)}\n")

            if cur_dragon_name.hp <= 0:
                del list_dragon[choose_dragon - 1]
                game_finished -= 1
        elif weapon_choose == 2:
            print(f"\n{main_hero.sword_attack(cur_dragon_name)}")
            if dragon_attack == 1:
                print(f"{cur_dragon_name.name} {cur_dragon_name.basic_attack(main_hero)}\n")
            else:
                print(f"{cur_dragon_name.name} {cur_dragon_name.special_attack(main_hero)}\n")

            if cur_dragon_name.hp <= 0:
                del list_dragon[choose_dragon - 1]
                game_finished -= 1

    print("Congratulations! You have defeated all 3 dragons, you have passed the trials.")
if __name__ == '__main__':
    main()
