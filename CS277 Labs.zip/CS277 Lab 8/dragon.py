import random
import entity


class Dragon(entity.Entity):
    def basic_attack(self,hero):
        tail_damage = random.randint(3,7)
        hero.take_damage(tail_damage)
        return f'smashes you with its tail for {tail_damage} damage!'

    def special_attack(self, hero):
        claw_damage = random.randint(4,8)
        hero.take_damage(claw_damage)
        return f'{hero.name} slashes you with its claws for {claw_damage} damage!'

