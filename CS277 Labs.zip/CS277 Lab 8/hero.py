import random
import entity


class Hero(entity.Entity):

    def arrow_attack(self, dragon):
        arrow_damage = random.randint(1,12)
        dragon.take_damage(arrow_damage)
        return f'You hit the {dragon.name} with an arrow for {arrow_damage} damage.'

    def sword_attack(self, dragon):
        sword_damage = (random.randint(1,6) + random.randint(1,6))
        dragon.take_damage(sword_damage)
        return f'You slash the {dragon.name} with your sword for {sword_damage} damage.'





