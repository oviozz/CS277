import dragon
import random


class FireDragon(dragon.Dragon):

    def __init__(self, name, max_hp, f_shots):
        super().__init__(name, max_hp)
        self.f_shots = f_shots

    def special_attack(self, hero):

        if self.f_shots > 0:
            fire_attack = random.randint(5, 9)
            hero.take_damage(fire_attack)
            self.f_shots -= 1
            return f' fire attack dealt the hero {fire_attack} damage'
        else:
            return ('No damage dealt from the attack')

    def __str__(self):
        return super().__str__() + f'\nFire Shots remaining: {self.f_shots}'
