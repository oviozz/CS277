import dragon
import random


class FlyingDragon(dragon.Dragon):
    def __init__(self, name, max_hp, swoops):
        super().__init__(name, max_hp)
        self.swoops = swoops


    def special_attack(self, hero):
        if self.swoops > 0:
            swoops_attack = random.randint(5, 8)
            hero.take_damage(swoops_attack)
            self.swoops -= 1
            return f'does a swoop attack at you for {swoops_attack} damage'

        else:
            return ('No damage dealt from the attack')


    def __str__(self):
        return super().__str__() + f'\nSwoop attacks remaining: {self.swoops}'