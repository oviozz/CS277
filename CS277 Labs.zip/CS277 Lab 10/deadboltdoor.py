import door
import random

class DeadboltDoor(door.Door):

    def __init__(self):
        self._bolt1 = random.randint(1,2) # 1 == unlocked, 2 == locked
        self._bolt2 = random.randint(1,2)


    def examine_door(self) -> str:
        return "A door with two deadbolts. Bothe need to be unlocked to open the door, but you can’t tell if each one is locked or unlocked."


    def menu_options(self) -> str:
        return f'1. Toogle bolt 1\n2. Toogle bolt 2'

    def get_menu_max(self) -> int:
        return 2

    def attempt(self, option):
        if option == 1:

            if self._bolt1 == 1:
                self._bolt1 = 2
                return "You've toggled bolt 1"
            else:
                self._bolt1 = 1
                return "You've toggled bolt 1"

        elif option == 2:
            if self._bolt1 == 1:
                self._bolt1 = 2
                return "You've toggled bolt 2"
            else:
                self._bolt1 = 1
                return "You've toggled bolt 2"


    def is_unlocked(self):

        if self._bolt1 == self._bolt2:
            return True
        return False


    def clue(self) -> str:
        return random.choice(['You jiggle the door… it seems like one of the bolts is unlocked.',"You jiggle the door… it seems like it’s completely locked"])


    def success(self) -> str:
        return 'You unlocked both deadbolts and opened the door'



