import door
import basic_door
import lockeddoor
import deadboltdoor
import random
import check_input

def open_door(door):

    print(door.examine_door())

    door_unlocked = False

    while door_unlocked != True:
        print(user_input := check_input.get_int_range(f'{door.menu_options()}\n', 1, door.get_menu_max()))
        print(door.attempt(user_input))

        if door.is_unlocked() == True:
            print(door.success())
            door_unlocked = True
        else:
            print(door.clue())



def main():
    print('Welcome to the Escape Room\nYou must unlock 3 doors to escape...')

    three_door = [basic_door.BasicDoor(),
                  lockeddoor.LockedDoor(),
                  deadboltdoor.DeadboltDoor()]

    for i in range(3):
        door_choose = three_door[random.randint(0,2)]
        open_door(door_choose)

    print('Congratulations! You escaped...this time.')





if __name__ == '__main__':
    main()