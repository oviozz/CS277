from abc import abstractmethod

class Door:

    @abstractmethod
    def examine_door(self) -> str:
        ...


    @abstractmethod
    def menu_options(self) -> str:
        ...

    @abstractmethod
    def get_menu_max(self) -> int:
        ...

    @abstractmethod
    def attempt(self, option) -> str:
        ...

    @abstractmethod
    def is_unlocked(self) -> str:
        ...

    @abstractmethod
    def clue(self) -> str:
        ...

    @abstractmethod
    def success(self) -> str:
        ...