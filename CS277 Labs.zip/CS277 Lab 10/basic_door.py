import door
import random

class BasicDoor(door.Door):

    def __init__(self):
        self._state = random.randint(1,2)
        self._input = 0

    def examine_door(self) -> str:
        return "You encounter a basic door, you can either push it or pull it to open."


    def menu_options(self) -> str:
        return f'1. Push\n2. Pull'

    def get_menu_max(self) -> int:
        return 2

    def attempt(self, option) -> str:

        if option == 1:
            self._input = 1
            return "You've pushed the door.\n"
        else:
            self._input = 2
            return "You've pulled the door.\n"


    def is_unlocked(self):

        if self._input == self._state:
            return True
        return False


    def clue(self) -> str:
        return 'Try the other way'


    def success(self) -> str:
        return 'Good Job. You have opened the door'

