import door
import random

class LockedDoor(door.Door):

    def __init__(self):
        self._key_location = random.randint(1,3)
        self._input = 0


    def examine_door(self) -> str:
        return "A locked door. Look around for the key."


    def menu_options(self) -> str:
        return f'1. Look under the mat\n2. Look under the flower pot\n3. Look under the fake rock'

    def get_menu_max(self) -> int:
        return 3

    def attempt(self, option) -> str:

        if option == 1:
            self._input = 1
            return "You've looked under the mat.\n"
        elif option == 2:
            self._input = 2
            return "You've looked under the flower pot.\n"
        else:
            self._input = 3
            return "You've looked under the rock"


    def is_unlocked(self):

        if self._input == self._key_location:
            return True
        return False


    def clue(self) -> str:
        return 'Look somewhere else'


    def success(self) -> str:
        return 'Good Job. You found and key and have opened the door'



