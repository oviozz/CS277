
import dice
import player as p
import check_input


print('-Yahtzee')

def take_turn(player):

    print(player)


    if player.has_pairs() == True:
        print('You got a pair!')

    elif player.has_three_of_a_kind() == True:
        print('You got 3 of a kind!')

    elif player.has_series() == True:
        print('You got a series of 3!')

    else:
        print('Aww. Too Bad.')

    print(f'Score = {player.get_points()}')

    player_dice.roll_dice()





if __name__ == '__main__':
    play = True
    player_dice = p.Player()

    while play == True:
        take_turn(player_dice)
        play = check_input.get_yes_no('Play again? (Y/N):')

    print(f'\nGame Over \nFinal Score = {player_dice.get_points()}')